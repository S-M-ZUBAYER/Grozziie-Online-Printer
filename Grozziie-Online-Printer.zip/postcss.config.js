// postcss.config.js (CommonJS format)
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
