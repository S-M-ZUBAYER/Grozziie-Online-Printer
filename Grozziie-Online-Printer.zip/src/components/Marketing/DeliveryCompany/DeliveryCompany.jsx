import React from "react";

const DeliveryCompany = () => {
  return <div>DeliveryCompany</div>;
};

export default DeliveryCompany;
