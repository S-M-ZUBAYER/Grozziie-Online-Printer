import React from "react";

const MarketingData = () => {
  return <div>MarketingData</div>;
};

export default MarketingData;
