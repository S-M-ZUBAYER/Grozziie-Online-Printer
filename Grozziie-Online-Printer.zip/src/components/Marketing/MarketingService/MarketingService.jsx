import React from "react";

const MarketingService = () => {
  return <div>MarketingService</div>;
};

export default MarketingService;
