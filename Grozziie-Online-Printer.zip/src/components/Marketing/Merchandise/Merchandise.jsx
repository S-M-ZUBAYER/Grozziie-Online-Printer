import React from "react";

const Merchandise = () => {
  return <div>Merchandise</div>;
};

export default Merchandise;
