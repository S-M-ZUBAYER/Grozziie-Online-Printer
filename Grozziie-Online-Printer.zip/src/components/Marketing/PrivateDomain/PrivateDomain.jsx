import React from "react";

const PrivateDomain = () => {
  return <div>PrivateDomain</div>;
};

export default PrivateDomain;
