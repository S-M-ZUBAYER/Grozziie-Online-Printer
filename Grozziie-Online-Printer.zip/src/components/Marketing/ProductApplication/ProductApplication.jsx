import React from "react";

const ProductApplication = () => {
  return <div>ProductApplication</div>;
};

export default ProductApplication;
