import React from "react";

const BasicSettings = () => {
  return <div>BasicSettings</div>;
};

export default BasicSettings;
