import React from "react";

const FrontPage = () => {
  return <div>FrontPage</div>;
};

export default FrontPage;
