import React from "react";

const PreShipment = () => {
  return <div>PreShipment</div>;
};

export default PreShipment;
