import React from "react";

const ProductAbbreviation = () => {
  return <div>ProductAbbreviation</div>;
};

export default ProductAbbreviation;
