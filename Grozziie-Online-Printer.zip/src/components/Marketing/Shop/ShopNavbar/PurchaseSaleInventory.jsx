import React from "react";

const PurchaseSaleInventory = () => {
  return <div>PurchaseSaleInventory</div>;
};

export default PurchaseSaleInventory;
