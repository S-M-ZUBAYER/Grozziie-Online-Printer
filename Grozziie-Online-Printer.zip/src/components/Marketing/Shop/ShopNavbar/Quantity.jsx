import React from "react";

const Quantity = () => {
  return <div>Quantity</div>;
};

export default Quantity;
