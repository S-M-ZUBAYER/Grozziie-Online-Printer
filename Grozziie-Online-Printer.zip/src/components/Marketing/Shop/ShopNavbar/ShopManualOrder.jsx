import React from "react";

const ShopManualOrder = () => {
  return <div>ShopManualOrder</div>;
};

export default ShopManualOrder;
