import React from "react";

const ShopSinglePrint = () => {
  return <div>ShopSinglePrint</div>;
};

export default ShopSinglePrint;
