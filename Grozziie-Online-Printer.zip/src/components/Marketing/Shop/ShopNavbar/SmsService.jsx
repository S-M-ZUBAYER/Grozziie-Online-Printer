import React from "react";

const SmsService = () => {
  return <div>SmsService</div>;
};

export default SmsService;
