import React from "react";

const StockList = () => {
  return <div>StockList</div>;
};

export default StockList;
