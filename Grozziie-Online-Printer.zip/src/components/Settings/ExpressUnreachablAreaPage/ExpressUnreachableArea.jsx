import React from 'react';

const ExpressUnreachableArea = () => {
    return (
        <div>
            This is the page for Express Unreachable Area
        </div>
    );
};

export default ExpressUnreachableArea;