import React from 'react';

const LogisticMachineSettings = () => {
    return (
        <div>
            This is the page for Logistic Machine Settings
        </div>
    );
};

export default LogisticMachineSettings;