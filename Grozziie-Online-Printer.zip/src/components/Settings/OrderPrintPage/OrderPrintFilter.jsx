import React from 'react';

const OrderPrintFilter = () => {
    return (
        <div>
            This is the page for order Print Filter
        </div>
    );
};

export default OrderPrintFilter;