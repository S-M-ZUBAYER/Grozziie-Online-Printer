import React from 'react';

const RecipientInfo = () => {
    return (
        <div>
            This is the page for Recipient Information
        </div>
    );
};

export default RecipientInfo;