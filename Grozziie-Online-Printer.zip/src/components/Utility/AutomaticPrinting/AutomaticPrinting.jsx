import React from "react";

const AutomaticPrinting = () => {
  return <div>AutomaticPrinting</div>;
};

export default AutomaticPrinting;
