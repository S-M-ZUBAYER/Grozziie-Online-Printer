import React from "react";

const ImportOrderAndShip = () => {
  return <div>ImportOrderAndShip</div>;
};

export default ImportOrderAndShip;
