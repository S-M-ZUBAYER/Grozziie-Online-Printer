import React from "react";

const LoginLog = () => {
  return <div>LoginLog</div>;
};

export default LoginLog;
