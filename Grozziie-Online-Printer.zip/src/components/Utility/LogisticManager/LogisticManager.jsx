import React from "react";

const LogisticManager = () => {
  return <div>LogisticManager</div>;
};

export default LogisticManager;
