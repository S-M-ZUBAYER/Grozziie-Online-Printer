import React from "react";

const MissionCenter = () => {
  return <div>MissionCenter</div>;
};

export default MissionCenter;
