import React from "react";

const OrderInquiry = () => {
  return <div>OrderInquiry</div>;
};

export default OrderInquiry;
