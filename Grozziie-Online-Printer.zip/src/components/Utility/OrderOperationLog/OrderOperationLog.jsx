import React from "react";

const OrderOperationLog = () => {
  return <div>OrderOperationLog</div>;
};

export default OrderOperationLog;
