import React from "react";

const PrintRecord = () => {
  return <div>PrintRecord</div>;
};

export default PrintRecord;
