import React from "react";

const ProductReportSummary = () => {
  return <div>ProductReportSummary</div>;
};

export default ProductReportSummary;
