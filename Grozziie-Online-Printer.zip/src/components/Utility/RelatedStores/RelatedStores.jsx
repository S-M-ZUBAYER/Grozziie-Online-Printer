import React from "react";

const RelatedStores = () => {
  return <div>RelatedStores</div>;
};

export default RelatedStores;
