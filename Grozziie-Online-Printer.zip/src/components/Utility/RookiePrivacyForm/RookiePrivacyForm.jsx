import React from "react";

const RookiePrivacyForm = () => {
  return <div>RookiePrivacyForm</div>;
};

export default RookiePrivacyForm;
