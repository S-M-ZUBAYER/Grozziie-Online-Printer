import React from "react";

const ScanAndShip = () => {
  return <div>ScanAndShip</div>;
};

export default ScanAndShip;
