import React from "react";

const AttributionQuery = () => {
  return <div>AttributionQuery</div>;
};

export default AttributionQuery;
