import React from "react";

const OddNumberSharing = () => {
  return <div>OddNumberSharing</div>;
};

export default OddNumberSharing;
