import React from "react";

const OrderNumberSharingExpressReconciliation = () => {
  return <div>OrderNumberSharingExpressReconciliation</div>;
};

export default OrderNumberSharingExpressReconciliation;
