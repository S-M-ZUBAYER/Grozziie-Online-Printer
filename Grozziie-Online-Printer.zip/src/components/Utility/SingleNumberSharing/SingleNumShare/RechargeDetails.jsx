import React from "react";

const RechargeDetails = () => {
  return <div>RechargeDetails</div>;
};

export default RechargeDetails;
