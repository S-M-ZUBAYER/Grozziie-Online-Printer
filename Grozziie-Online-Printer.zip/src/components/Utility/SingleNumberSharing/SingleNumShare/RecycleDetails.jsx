import React from "react";

const RecycleDetails = () => {
  return <div>RecycleDetails</div>;
};

export default RecycleDetails;
