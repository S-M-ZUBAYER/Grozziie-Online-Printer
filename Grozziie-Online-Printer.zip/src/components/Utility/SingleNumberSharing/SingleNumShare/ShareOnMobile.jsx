import React from "react";

const ShareOnMobile = () => {
  return <div>ShareOnMobile</div>;
};

export default ShareOnMobile;
