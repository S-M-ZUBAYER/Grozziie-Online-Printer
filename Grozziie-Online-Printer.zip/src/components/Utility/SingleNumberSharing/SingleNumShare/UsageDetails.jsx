import React from "react";

const UsageDetails = () => {
  return <div>UsageDetails</div>;
};

export default UsageDetails;
