import React from "react";

const UnusualOrder = () => {
  return <div>UnusualOrder</div>;
};

export default UnusualOrder;
