import React from 'react';

const Utility = () => {
    return (
        <div>
            This is Utility page
        </div>
    );
};

export default Utility;