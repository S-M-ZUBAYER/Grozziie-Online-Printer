// import React, { useEffect, useState } from "react";
// import {
//   Elements,
//   PaymentElement,
//   useStripe,
//   useElements,
// } from "@stripe/react-stripe-js";
// import { loadStripe } from "@stripe/stripe-js";
// import axios from "axios";
// import { useSelector } from "react-redux";

// const stripePromise = loadStripe(import.meta.env.VITE_PAYMENT_KEY);

// const convertToCents = (amount) => Math.round(amount * 100);
// import calculatePaymentExpireTime from "../../lib/calculatePaymentExpireTime";
// import { useLocation } from "react-router-dom";

// const PaymentForm = ({ email, setEmail, duration, amount, currency }) => {
//   const stripe = useStripe();
//   const elements = useElements();
//   const currentUser = useSelector((state) => state.user.accountUser);

//   const storedShopPlatform = localStorage.getItem("SelectedPlatform");
//   const [cipher, setCipher] = useState(() => {
//     const stored = localStorage.getItem("tiktokShopInfo");
//     return stored ? JSON.parse(stored) : [];
//   });
//   const [lazadaShopId, setlazadaShopId] = useState(() => {
//     const stored = localStorage.getItem("lazadaShopInfo");
//     return stored ? JSON.parse(stored) : [];
//   });
//   const [shopeeShopId, setShopeeShopId] = useState(() => {
//     const stored = localStorage.getItem("shopeeShopInfo");
//     return stored ? JSON.parse(stored) : [];
//   });

//   const [error, setError] = useState(null);
//   const [success, setSuccess] = useState(false);
//   const [loading, setLoading] = useState(false);

//   const fetchClientSecret = async () => {
//     try {
//       const { data } = await axios.post(
//         "https://grozziieget.zjweiting.com:8033/tht/payment-intent",
//         // "http://localhost:2000/tht/payment-intent",
//         {
//           amount: convertToCents(amount),
//           currency,
//         }
//       );
//       await storePaymentInfo();
//       await confirmPayment(data.clientSecret);
//     } catch (err) {
//       console.error("Failed to create payment intent:", err);
//     }
//   };

//   const confirmPayment = async (clientSecret) => {
//     if (!stripe || !elements) return;

//     try {
//       await elements.submit();
//       const { error, paymentIntent } = await stripe.confirmPayment({
//         elements,
//         clientSecret,
//         confirmParams: {
//           payment_method_data: {
//             billing_details: {
//               email: currentUser,
//             },
//           },
//           return_url: `${window.location.origin}/onlineprint/success?email=${currentUser}&duration=${duration}`,
//         },
//       });

//       if (error) {
//         setError(error.message);
//       } else if (paymentIntent?.status === "succeeded") {
//         setSuccess(true);
//       }
//     } catch (error) {
//       console.error("Payment confirmation failed:", error);
//       setError("An error occurred while processing your payment.");
//     }
//   };

//   const storePaymentInfo = async () => {
//     const paymentInfo = {
//       email: currentUser,
//       shopPlatform: storedShopPlatform,
//       shopName:
//         storedShopPlatform === "shopee"
//           ? shopeeShopId[0]?.id
//           : storedShopPlatform === "lazada"
//           ? lazadaShopId[0]?.id
//           : cipher[0].id,
//       paymentTime: new Date().toISOString().split(".")[0] + "Z",
//       paymentExpireTime: calculatePaymentExpireTime(duration),
//       amount,
//       currency,
//     };
//     try {
//       const { data } = await axios.post(
//         "https://grozziieget.zjweiting.com:8033/tht/printerUserPaymentInfo/add",
//         // "http://localhost:2000/tht/printerUserPaymentInfo/add",
//         paymentInfo
//       );
//       localStorage.setItem("paymentInfo", JSON.stringify(data));
//     } catch (err) {
//       console.error("Failed to store payment info:", err);
//     }
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     if (!stripe || !elements) return;

//     if (!currentUser || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(currentUser)) {
//       setError("Please enter a valid email address.");
//       return;
//     }
//     setLoading(true);
//     setError(null);
//     await fetchClientSecret();
//     setLoading(false);
//   };

//   return (
//     <div className="flex justify-center items-center min-h-screen bg-gray-100 gap-10">
//       <div className="w-[60vw] max-w-md p-6">
//         <h2 className="text-2xl font-bold mb-4 text-center">Stripe Payment</h2>
//         {success ? (
//           <p className="text-green-600 text-center">Payment Successful!</p>
//         ) : (
//           <form onSubmit={handleSubmit} className="space-y-4">
//             {/* Email Input */}
//             <div>
//               <label htmlFor="email" className="block text-sm font-medium">
//                 Email <span className="text-red-500">*</span>
//               </label>
//               <input
//                 type="email"
//                 id="email"
//                 className="w-full p-2 border rounded"
//                 placeholder="Enter your email"
//                 value={currentUser}
//                 onChange={(e) => setEmail(e.target.value)}
//                 required
//                 readOnly
//               />
//             </div>

//             <PaymentElement />

//             <button
//               type="submit"
//               disabled={!stripe || loading}
//               className={`w-full p-3 rounded font-semibold ${
//                 loading
//                   ? "bg-gray-400"
//                   : "bg-blue-700 text-white hover:bg-blue-800"
//               }`}
//             >
//               {loading ? "Processing..." : `Pay $${amount}`}
//             </button>
//           </form>
//         )}
//         {error && (
//           <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
//             <div className="bg-white w-96 rounded-2xl shadow-lg p-6 relative animate-fadeIn">
//               {/* Close Button */}
//               <button
//                 onClick={() => setError(null)}
//                 className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
//               >
//                 ✖
//               </button>

//               {/* Error Icon */}
//               <div className="flex justify-center">
//                 <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
//                   <svg
//                     xmlns="http://www.w3.org/2000/svg"
//                     fill="none"
//                     viewBox="0 0 24 24"
//                     strokeWidth={1.5}
//                     stroke="red"
//                     className="w-10 h-10"
//                   >
//                     <path
//                       strokeLinecap="round"
//                       strokeLinejoin="round"
//                       d="M12 9v3m0 4h.01m-.01-14a9 9 0 110 18 9 9 0 010-18z"
//                     />
//                   </svg>
//                 </div>
//               </div>

//               {/* Title */}
//               <h2 className="text-xl font-semibold text-center mt-4 text-red-600">
//                 Something went wrong
//               </h2>

//               {/* Error Text */}
//               <p className="text-center text-gray-600 mt-2">{error}</p>

//               {/* OK Button */}
//               <button
//                 onClick={() => setError(null)}
//                 className="mt-5 w-full bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition"
//               >
//                 OK
//               </button>
//             </div>
//           </div>
//         )}
//       </div>

//       {/* Optional illustration */}
//       <div>
//         <img
//           src="paymentIllustration.svg"
//           alt="Illustration"
//           className="h-[70vh]"
//         />
//       </div>
//     </div>
//   );
// };

// const Payment = () => {
//   const location = useLocation();
//   const packageName = location.state?.plan?.name || "basic";
//   const duration = location.state?.plan?.duration || "1month";

//   const initialPrice = location.state?.plan?.amount;
//   const [currency] = useState("usd");

//   const [email, setEmail] = useState("");

//   return (
//     <Elements
//       stripe={stripePromise}
//       options={{
//         mode: "payment",
//         amount: convertToCents(initialPrice),
//         currency,
//         appearance: {
//           theme: "flat",
//           variables: {
//             colorPrimary: "#004368",
//             colorBackground: "transparent",
//             colorText: "#000",
//             colorDanger: "#df1b41",
//             fontFamily: "Poppins, sans-serif",
//             borderRadius: "8px",
//             spacingUnit: "6px",
//           },
//           rules: {
//             ".Input": {
//               backgroundColor: "transparent",
//               boxShadow: "none",
//               borderColor: "transparent",
//             },
//             ".Input:focus": {
//               borderColor: "transparent",
//             },
//           },
//         },
//       }}
//     >
//       <PaymentForm
//         email={email}
//         setEmail={setEmail}
//         duration={duration}
//         amount={initialPrice}
//         currency={currency}
//       />
//     </Elements>
//   );
// };

// export default Payment;

import React, { useEffect, useState } from "react";
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import axios from "axios";
import { useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom"; // Add useNavigate

const stripePromise = loadStripe(import.meta.env.VITE_PAYMENT_KEY);

const convertToCents = (amount) => Math.round(amount * 100);
import calculatePaymentExpireTime from "../../lib/calculatePaymentExpireTime";
import { useTranslation } from "react-i18next";

const PaymentForm = ({ email, setEmail, duration, amount, currency }) => {
  const stripe = useStripe();
  const elements = useElements();
  const currentUser = useSelector((state) => state.user.accountUser);
  const navigate = useNavigate(); // Add this
  const { t } = useTranslation();

  const storedShopPlatform = localStorage.getItem("SelectedPlatform");
  const [cipher, setCipher] = useState(() => {
    try {
      const currentStoreId = localStorage.getItem("tiktokAuthCipher");
      const stored = localStorage.getItem("tiktokShopInfo");

      if (!stored || !currentStoreId) return null;

      const shops = JSON.parse(stored);
      return (
        shops.find((shop) => String(shop.cipher) === String(currentStoreId)) ||
        null
      );
    } catch (error) {
      console.error("Error loading TikTok shop:", error);
      return null;
    }
  });

  const [lazadaShopId, setLazadaShopId] = useState(() => {
    try {
      const currentStoreId = localStorage.getItem("lazadaAppKeyShopInfo");
      const stored = localStorage.getItem("lazadaShopInfo");

      if (!stored || !currentStoreId) return null;

      const shops = JSON.parse(stored);
      return (
        shops.find((shop) => String(shop.cipher) === String(currentStoreId)) ||
        null
      );
    } catch (error) {
      console.error("Error loading Lazada shop:", error);
      return null;
    }
  });

  const [shopeeShopId, setShopeeShopId] = useState(() => {
    try {
      const currentStoreId = localStorage.getItem("shopeeAppKey");
      const stored = localStorage.getItem("shopeeShopInfo");

      if (!stored || !currentStoreId) return null;

      const shops = JSON.parse(stored);
      return (
        shops.find((shop) => String(shop.cipher) === String(currentStoreId)) ||
        null
      );
    } catch (error) {
      console.error("Error loading Shopee shop:", error);
      return null;
    }
  });

  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showShopModal, setShowShopModal] = useState(false); // Add this

  const fetchClientSecret = async () => {
    // Determine shopName based on platform
    const shopName =
      storedShopPlatform === "shopee"
        ? String(shopeeShopId?.cipher)
        : storedShopPlatform === "lazada"
          ? lazadaShopId?.cipher
          : cipher?.id;

    // Check if platform and shop are selected
    if (!storedShopPlatform || !shopName) {
      setShowShopModal(true); // Show modal
      return;
    }

    try {
      const { data } = await axios.post(
        "https://grozziieget.zjweiting.com:8033/tht/payment-intent",
        {
          amount: convertToCents(amount),
          currency,
        },
      );
      await confirmPayment(data.clientSecret);
    } catch (err) {
      console.error("Failed to create payment intent:", err);
    }
  };

  const confirmPayment = async (clientSecret) => {
    if (!stripe || !elements) return;

    try {
      await elements.submit();

      // Store payment data in localStorage to be used by success page
      const paymentData = {
        email: currentUser,
        shopPlatform: storedShopPlatform,
        shopName:
          storedShopPlatform === "shopee"
            ? String(shopeeShopId?.cipher)
            : storedShopPlatform === "lazada"
              ? lazadaShopId?.cipher
              : cipher?.id,
        duration,
        amount,
        currency,
      };

      localStorage.setItem("pendingPaymentData", JSON.stringify(paymentData));

      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        clientSecret,
        confirmParams: {
          payment_method_data: {
            billing_details: {
              email: currentUser,
            },
          },
          return_url: `${window.location.origin}/onlineprint/success?email=${currentUser}&duration=${duration}&amount=${amount}&currency=${currency}`,
        },
      });

      if (error) {
        setError(error.message);
      } else if (paymentIntent?.status === "succeeded") {
        setSuccess(true);
      }
    } catch (error) {
      console.error("Payment confirmation failed:", error);
      setError("An error occurred while processing your payment.");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    if (!currentUser || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(currentUser)) {
      setError("Please enter a valid email address.");
      return;
    }
    setLoading(true);
    setError(null);
    await fetchClientSecret();
    setLoading(false);
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100 gap-10">
      <div className="w-[60vw] max-w-md p-6">
        <h2 className="text-2xl font-bold mb-4 text-center">Stripe Payment</h2>
        {success ? (
          <p className="text-green-600 text-center">Payment Successful!</p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email Input */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium">
                Email <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                id="email"
                className="w-full p-2 border rounded"
                placeholder={t("enter_email")}
                value={currentUser}
                onChange={(e) => setEmail(e.target.value)}
                required
                readOnly
              />
            </div>

            <PaymentElement />

            <button
              type="submit"
              disabled={!stripe || loading}
              className={`w-full p-3 rounded font-semibold ${
                loading
                  ? "bg-gray-400"
                  : "bg-blue-700 text-white hover:bg-blue-800"
              }`}
            >
              {loading ? "Processing..." : `Pay $${amount}`}
            </button>
          </form>
        )}

        {/* Shop Selection Modal */}
        {showShopModal && (
          <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
            <div className="bg-white w-96 rounded-2xl shadow-lg p-6 relative animate-fadeIn">
              {/* Warning Icon */}
              <div className="flex justify-center">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="#f59e0b"
                    className="w-10 h-10"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"
                    />
                  </svg>
                </div>
              </div>

              {/* Title */}
              <h2 className="text-xl font-semibold text-center mt-4 text-gray-800">
                {t("SelectShopFirst")}
              </h2>

              {/* Message */}
              <p className="text-center text-gray-600 mt-2">
                {t("SelectShopFirst")}
              </p>

              {/* OK Button */}
              <button
                onClick={() => {
                  setShowShopModal(false);
                  navigate("/onlineprint");
                }}
                className="mt-5 w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition"
              >
                {t("Ok")}
              </button>
            </div>
          </div>
        )}

        {/* Error Modal */}
        {error && (
          <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
            <div className="bg-white w-96 rounded-2xl shadow-lg p-6 relative animate-fadeIn">
              {/* Close Button */}
              <button
                onClick={() => setError(null)}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
              >
                ✖
              </button>

              {/* Error Icon */}
              <div className="flex justify-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="red"
                    className="w-10 h-10"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 9v3m0 4h.01m-.01-14a9 9 0 110 18 9 9 0 010-18z"
                    />
                  </svg>
                </div>
              </div>

              {/* Title */}
              <h2 className="text-xl font-semibold text-center mt-4 text-red-600">
                Something went wrong
              </h2>

              {/* Error Text */}
              <p className="text-center text-gray-600 mt-2">{error}</p>

              {/* OK Button */}
              <button
                onClick={() => setError(null)}
                className="mt-5 w-full bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition"
              >
                OK
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Optional illustration */}
      <div>
        <img
          src="paymentIllustration.svg"
          alt="Illustration"
          className="h-[70vh]"
        />
      </div>
    </div>
  );
};

const Payment = () => {
  const location = useLocation();
  const packageName = location.state?.plan?.name || "basic";
  const duration = location.state?.plan?.duration || "1month";

  const initialPrice = location.state?.plan?.amount;
  const [currency] = useState("usd");

  const [email, setEmail] = useState("");

  return (
    <Elements
      stripe={stripePromise}
      options={{
        mode: "payment",
        amount: convertToCents(initialPrice),
        currency,
        appearance: {
          theme: "flat",
          variables: {
            colorPrimary: "#004368",
            colorBackground: "transparent",
            colorText: "#000",
            colorDanger: "#df1b41",
            fontFamily: "Poppins, sans-serif",
            borderRadius: "8px",
            spacingUnit: "6px",
          },
          rules: {
            ".Input": {
              backgroundColor: "transparent",
              boxShadow: "none",
              borderColor: "transparent",
            },
            ".Input:focus": {
              borderColor: "transparent",
            },
          },
        },
      }}
    >
      <PaymentForm
        email={email}
        setEmail={setEmail}
        duration={duration}
        amount={initialPrice}
        currency={currency}
      />
    </Elements>
  );
};

export default Payment;
